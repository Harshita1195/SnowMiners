-- ==========================================
-- This script runs when the app is installed 
-- ==========================================

-- Create Application Role and Schema
create application role if not exists app_instance_role;
create or alter versioned schema app_instance_schema;

-- Share data
create or replace view app_instance_schema.EPC_V as select * from shared_content_schema.EPC_V;
create or replace view app_instance_schema.HPI_V as select * from shared_content_schema.HPI_V;
create or replace view app_instance_schema.EMISSIONSINTENSITY_V as select * from shared_content_schema.EMISSIONSINTENSITY_V;
create or replace view app_instance_schema.ELECTRICITYUSEPROPORTION_V as select * from shared_content_schema.ELECTRICITYUSEPROPORTION_V;

-- Create Streamlit app
create or replace streamlit app_instance_schema.streamlit from '/libraries' main_file='streamlit.py';

create or replace procedure app_instance_schema.update_reference(ref_name string, operation string, ref_or_alias string)
returns string
language sql
as $$
begin
  case (operation)
    when 'ADD' then
       select system$set_reference(:ref_name, :ref_or_alias);
    when 'REMOVE' then
       select system$remove_reference(:ref_name, :ref_or_alias);
    when 'CLEAR' then
       select system$remove_all_references();
    else
       return 'Unknown operation: ' || operation;
  end case;
  return 'Success';
end;
$$;

-- Grant usage and permissions on objects
grant usage on schema app_instance_schema to application role app_instance_role;
grant SELECT on view app_instance_schema.EPC_V to application role app_instance_role;
grant SELECT on view app_instance_schema.HPI_V to application role app_instance_role;
grant SELECT on view app_instance_schema.EMISSIONSINTENSITY_V to application role app_instance_role;
grant SELECT on view app_instance_schema.ELECTRICITYUSEPROPORTION_V to application role app_instance_role;
grant usage on streamlit app_instance_schema.streamlit to application role app_instance_role;
grant usage on procedure app_instance_schema.update_reference(string, string, string) to application role app_instance_role;
